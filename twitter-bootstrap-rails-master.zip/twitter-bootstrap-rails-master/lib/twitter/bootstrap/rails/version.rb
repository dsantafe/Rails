module Twitter
  module Bootstrap
    module Rails
      VERSION = "4.0.0"
    end
  end
end
