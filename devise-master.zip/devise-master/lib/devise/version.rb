# frozen_string_literal: true

module Devise
  VERSION = "4.5.0".freeze
end
