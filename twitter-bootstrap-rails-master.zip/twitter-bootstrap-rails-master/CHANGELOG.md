<ul>
  <li>Version 0.0.5 deprecated</li>
  <li>Asset files updated to latest and removed version numbers</li>
  <li>Implemented Less::Rails Railtie to use with LESS</li>
  <li>Fixed railtie to only initialize Less when installed</li>
  <li>New branch for the static version of Bootstrap (w/o Less) - check static branch</li>
  <li>Added path to support heroku deploy</li>
  <li>Rake precompile issue fixed</li>
  <li>Updated asset files to 1.4.0</li>
  <li>Updated dependency less-rails (now requires 2.1.0)</li>
  <li>Added generators</li>
  <li>Fixed generators</li>
  <li>Fixed class name conflicts from (bootstrap.js.coffee)</li>
  <li>Fixed jquery-rails gem version dependency</li>
  <li>Updated asset files</li>
  <li>Added new generators (install, layout and themed)</li>
  <li>Compatibility to Rails 3.2</li>
  <li>Transitioning to 2.0</li>
  <li>Released gem v.2.0rc0</li>
  <li>Added Haml and Slim support</li>
  <li>Added Responsive layout support</li>
  <li>Fixes and release 2.0.0</li>
  <li>Updated to v2.0.1, versioned v2.0.1.0</li>
  <li>Released gem v.2.0.3</li>
  <li>Released gem v.2.0.4</li>
  <li>Released gem v.2.0.5</li>
  <li>Added SimpleForm support</li>
  <li>Added FontAwesome support</li>
  <li>Released gem v.2.0.6</li>
  <li>Released gem v.2.0.7</li>
  <li>Released gem v.2.0.8</li>
  <li>Released gem v.2.0.9 (Bootstrap 2.0.4 and FontAwesome 2.0 support)</li>
  <li>Released gem v.2.1.0 (JRuby support)</li>
  <li>Released gem v.2.1.1 (minor fixes)</li>
  <li>Flash block message helper added</li>
  <li>Released gem v.2.1.2 (minor fixes and updated to Twitter Bootstrap 2.1.0)</li>
  <li>Released gem v.2.1.3 (minor fixes and updated to Twitter Bootstrap 2.1.1)</li>
  <li>Released gem v.2.1.4 (minor fixes)</li>
  <li>Released gem v.2.1.5 (minor fixes, install generator detects JavaScript template engine, updated to Twitter Bootstrap 2.2.1)</li>
  <li>Released gem v.2.1.6 (minor fixes)</li>
  <li>Added static stylesheets support</li>
  <li>Released gem v.2.1.8 and updated to Twitter Bootstrap 2.2.2</li>
  <li>Released gem v.2.1.9</li>
  <li>Released gem v.2.2.0 (Font Awesome 3)</li>
  <li>Released gem v.2.2.1 (minor fixes and updates)</li>
  <li>Released gem v.2.2.2 (Bootstrap 2.3.0)</li>
  <li>Released gem v.2.2.3 (Minor fixes)</li>
  <li>Released gem v.2.2.4 (Minor fixes)</li>
  <li>Released gem v.2.2.5 (Bootstrap 2.3.1)</li>
  <li>Released gem v.2.2.6</li>
  <li>Released gem v.2.2.7 (Fixes)</li>
  <li>Releases gem v.2.2.8</li>
  <li>Releases gem v.3.2.1</li>
  <li>Releases gem v.3.2.2</li>
  <li>Dropped FontAwesome support, see #889</li>
  <li>Releases gem v.4.0.0> (master changes)<li>
</ul>
