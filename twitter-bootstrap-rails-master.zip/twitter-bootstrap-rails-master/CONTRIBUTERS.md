<ul>
  <li>Ben Lovell</li>
  <li>Daniel Morris</li>
  <li>Bradly Feeley</li>
  <li>Guilherme Moreira</li>
  <li>Alex Behar</li>
  <li>Brandon Keene</li>
  <li>Anthony Corcutt</li>
  <li>Colin Warren</li>
  <li>Giovanni Cappellotto</li>
  <li>Masakuni Kato</li>
  <li>Gudleik Rasch</li>
  <li>Thomas Volkmar Worm</li>
  <li>Thiago Almeida</li>
  <li>Sébastien Grosjean</li>
  <li>Nick DeSteffen</li>
  <li>Christian Joudrey</li>
  <li>Todd Baur</li>
  <li>Leonid Shevtsov</li>
  <li>Christophe Maximin</li>
</ul>