# frozen_string_literal: true

class Publisher::RegistrationsController < ApplicationController
end
